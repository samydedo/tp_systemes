
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>


int main()
{
	printf("Je suis le fils 1 et mon PID est : %ld. \n", (long)getpid());
	
	return 0;
}

